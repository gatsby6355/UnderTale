package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PlayController2 implements Initializable{
	
	@FXML
	private ImageView player, background_material_1, boss_face1, boss_face2;
	@FXML
	private ImageView enemy31, enemy32, enemy33, enemy34, enemy35, enemy36, enemy37, enemy38, enemy39, enemy310;		// Stage 3
	@FXML
	private ImageView enemy41, enemy42, enemy43, 
			enemy_lazer41, enemy_lazer42, enemy_lazer43, enemy_lazer44, enemy_lazer45, enemy_lazer46;		// Stage 4
	@FXML
	private ImageView enemy51, enemy52, enemy53, enemy54;
	@FXML
    private Rectangle play_area;
	@FXML
	private Pane gameover_pane1;
	@FXML
	private Label playtime;
	@FXML
	private Pane Enemy_Attack3, Enemy_Attack4, Enemy_Attack5;
	@FXML
	private Button gameover1;
	@FXML
	private Text player_score, chat_hit, chat_usual1, chat_usual2, chat_usual3, chat_in_1, chat_in_2;
	
	private FXSound sound = new FXSound();
	
	public ArrayList<ImageView> EnemyList = new ArrayList<ImageView>();		// ���� �����ϴ� �迭
	public ArrayList<Pane> StageList = new ArrayList<Pane>();				// ������ �����ϴ� �迭
	public ArrayList<Double> EnemyList_Xspeed = new ArrayList<Double>();
	public ArrayList<Double> EnemyList_Yspeed = new ArrayList<Double>();
	public ArrayList<Double> EnemyList_Xspeed_real = new ArrayList<Double>();
	public ArrayList<Double> EnemyList_Yspeed_real = new ArrayList<Double>();
	double delaytime = 0.8;				// �ǰ� ������ �ð�
	
	boolean Key_up = false;
	boolean Key_down = false;
	boolean Key_left = false;
	boolean Key_right = false;
	
	boolean boss_chat = false;
	boolean boss_chat_usual = false;
	double boss_chat_delay = 4;
	double boss_chat_delaytime = 0;
	int random_chat=0;
	ArrayList <Text> boss_chat_list = new ArrayList<Text>();
	
	boolean player_state = false;
	boolean player_state_delay = false;
	double player_state_delaytime = 0;
	double playerXpos = 0;
	double playerYpos = 0;
	double player_speed = 0.8;
	
	double enemyXspeed = 0;
	double enemyYspeed = 0;
	double enemyXspeed_real=0;
	double enemyYspeed_real=0;
	double Enemy_Attack5_time=0;
	
	boolean textview = false;
	public Timeline timeLine;

	int enemy_count = 1; //enemy ����
	ArrayList <Double> enemyX_Inc = new ArrayList<Double>(); // x������
	ArrayList <Double> enemyY_Inc = new ArrayList<Double>(); // y������
	double stage_time = 0; //���� �ð�
	int loopcount = 0;//
	int enemyRotate = 0;//
	boolean[] enemyUp = new boolean[3];
	boolean[] enemyFlag = new boolean[2];
	boolean[] enemylazer = new boolean[3];
	

	@Override
	public void initialize(URL location, ResourceBundle resources){
		initial_game();
		
		player.setOnKeyPressed(event -> {
			try {
				handlePlayer_1(event);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		
		player.setOnKeyReleased(event -> {
			try {
				handlePlayer_2(event);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		
		timeLine = new Timeline(new KeyFrame(Duration.millis(10), e-> run(e)));
		timeLine.setCycleCount(Timeline.INDEFINITE);
		timeLine.play();
	}

	private void initial_game() {
		//bgm play
		sound.BGMPlay("game2");
		background_material_1.setVisible(false);
		
		//player
		PlayController.PLAYER_HP++;
		player_state = false;
		player_state_delaytime = 0;
		player_score.setText("A");
		player.setFocusTraversable(true);
		
		// set game level
		setStage3();
		PlayController.GAME_LEVEL = 3;
		player_state = false;
		
		//boss chat
		boss_chat = false;
		chat_hit.setVisible(false);
		chat_usual1.setVisible(false);
		chat_usual2.setVisible(false);
		chat_usual3.setVisible(false);
		boss_chat_list.add(chat_usual1);
		boss_chat_list.add(chat_usual2);
		boss_chat_list.add(chat_usual3);
		boss_chat_delaytime = 0;
		textview = true;
		
		// set Key
		Key_up = false;
		Key_down = false;
		Key_left = false;
		Key_right = false;
		
		// add the stage pane
		Enemy_Attack3.setVisible(false);
		Enemy_Attack4.setVisible(false);
		Enemy_Attack5.setVisible(false);
		
		StageList.clear();
		StageList.add(Enemy_Attack3);
		StageList.add(Enemy_Attack4);
		StageList.add(Enemy_Attack5);
	}

	private void run(ActionEvent e){
		
		// set Xpos, Ypos
		playerXpos = player.getX();
		playerYpos = player.getY();
		player_state = crash();
		
		move_player();
		if(textview) {
			boss_chat_usual();
		}
		
		// �ǰ� �� �����̰� �����ϸ�,
		if(player_state_delay) {		// ������ player_state�� true ����
			player_state_delaytime = player_state_delaytime + timeLine.getCurrentTime().toSeconds();
			if(player_state) {
				player_state = false;
			}
			if(delaytime < player_state_delaytime) {
				player_state_delay = false;
				player_state_delaytime = 0;
			}
		}
		else {
			if(player_state) {			// �ǰݽ�
				PlayController.PLAYER_HP--;
				player_state_delay = true;
				boss_chat_hit();
			}
		}
		// **GAME_LEVEL
		if(PlayController.GAME_LEVEL == 3) {
			stage3();
		}
		else if(PlayController.GAME_LEVEL == 4) {
			stage4();
		}
		else if(PlayController.GAME_LEVEL == 5) {
			stage5();
		}
		else if(PlayController.GAME_LEVEL == 6) {			// �¸��� ���
			PlayController.PlayerScore = player_score.getText();
			gameover_pane1.setVisible(true);
			game_end_set();
			gameover1.setOnAction(event->{
				try {
					gotoGameWin();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			});
		}
		
		// ** PLAYER_SCORE
		if(PlayController.PLAYER_HP == 12) {
			player_score.setText("A+");
		}
		else if(PlayController.PLAYER_HP == 11) {
			player_score.setText("A0");
		}
		else if(PlayController.PLAYER_HP == 10) {
			player_score.setText("A-");
		}
		else if(PlayController.PLAYER_HP == 9) {
			player_score.setText("B+");
		}
		else if(PlayController.PLAYER_HP == 8) {
			player_score.setText("B0");
		}
		else if(PlayController.PLAYER_HP == 7) {
			player_score.setText("B-");
		}
		else if(PlayController.PLAYER_HP == 6) {
			player_score.setText("C+");
		}
		else if(PlayController.PLAYER_HP == 5) {
			player_score.setText("C0");
		}
		else if(PlayController.PLAYER_HP == 4) {
			player_score.setText("C-");
		}
		else if(PlayController.PLAYER_HP == 3) {
			player_score.setText("D+");
		}
		else if(PlayController.PLAYER_HP == 2) {
			player_score.setText("D0");
		}
		else if(PlayController.PLAYER_HP == 1) {
			player_score.setText("D-");
		}
		else if(PlayController.PLAYER_HP == 0) {					// ���� ���
			gameover_pane1.setVisible(true);
			game_end_set();
			gameover1.setOnAction(event->{
				try {
					gotoGameOver();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			});
		}
	}
	
	private void boss_chat_hit() {
		boss_hit_motion1();
		if(boss_chat_usual) {
			if(boss_chat) {			// boss_chat�� �����ִ°�� 
				boss_chat=false;
			}
			boss_face1.setVisible(false);
			boss_face2.setVisible(true);
			sound.EffectPlay("pitan");
			boss_chat_delaytime = -2;
			chat_hit.setVisible(true);
			boss_chat_list.get(random_chat).setVisible(false);
		}
	}
	
	private void boss_chat_usual() {
		boss_chat_delaytime =  boss_chat_delaytime + timeLine.getCurrentTime().toSeconds();
		if(!boss_chat_usual) {
			if(boss_chat_delaytime < 1.5) {
				chat_in_1.setVisible(true);
			}
			else if(boss_chat_delaytime < 3) {
				chat_in_1.setVisible(false);
				chat_in_2.setVisible(true);
			}
			else if(boss_chat_delaytime < 4.5) {
				chat_in_2.setVisible(false);
				boss_chat_usual = true;
				boss_chat_delaytime = 0;
			}
		}
		else {
			if(boss_chat_delaytime > 0) {
				chat_hit.setVisible(false);
				boss_hit_motion2();
				boss_face2.setVisible(false);
				boss_face1.setVisible(true);
			}
			
			if(!boss_chat) {
				if(boss_chat_delaytime > boss_chat_delay) {	// 4�� ���� ��ȭ�� �ٲ�
				random_chat = (int)(Math.random()*boss_chat_list.size());
				boss_chat_list.get(random_chat).setVisible(true);
				boss_chat = true;
				}
			}
			else {
				if(boss_chat_delaytime > 5.5) {
					boss_chat_list.get(random_chat).setVisible(false);		// ���� �� false
					boss_chat_delaytime=0;
					boss_chat=false;
				}
			}
		}
	}
	
	private void boss_hit_motion1() {
		background_material_1.setVisible(true);
		double i=0.3;
		while(i > 0.5){
			background_material_1.setOpacity(i);
			i = i + 0.1;
		}
	}
	
	private void boss_hit_motion2() {
		double i=0.5;
		while(i < 0.3){
			background_material_1.setOpacity(i);
			i = i - 0.1;
		}
		background_material_1.setVisible(false);
	}

	private void setStage3() {
	      EnemyList.clear();
	      EnemyList.add(enemy31);
	      EnemyList.add(enemy32);
	      EnemyList.add(enemy33);
	      EnemyList.add(enemy34);
	      EnemyList.add(enemy35);
	      EnemyList.add(enemy36);
	      EnemyList.add(enemy37);
	      EnemyList.add(enemy38);
	      EnemyList.add(enemy39);
	      EnemyList.add(enemy310);
	      
	      enemyXspeed = 1.2;
	      enemyYspeed = 1.2;
	      
	      enemy_count = 0;
	      stage_time = 0;
	      loopcount = 0 ;
	      
	      enemyX_Inc.clear();
	      enemyY_Inc.clear();
	      
	      for(int i=0; i<EnemyList.size();i++) {
	         enemyX_Inc.add(0.0);
	         enemyY_Inc.add(0.0);
	      }
	      
	   }

	private void setStage4() {
         EnemyList.clear();
         EnemyList.add(enemy41);
         EnemyList.add(enemy42);
         EnemyList.add(enemy43);
         EnemyList.add(enemy_lazer41);
         EnemyList.add(enemy_lazer42);
         EnemyList.add(enemy_lazer43);
         EnemyList.add(enemy_lazer44);
         EnemyList.add(enemy_lazer45);
         EnemyList.add(enemy_lazer46);
         
         for(int i = 0; i < 2; i++) 
         EnemyList.get(i).setLayoutY((int)(Math.random() * 1000) % 181 + 520);
         EnemyList.get(1).setLayoutX(240);
         EnemyList.get(2).setLayoutX((int)(Math.random() * 1000) % 371 + 300);
         EnemyList.get(2).setLayoutY(460);
         
         enemyXspeed = 10;
         enemyYspeed = 3;
         enemyRotate = 4;
         
         loopcount=0;
         enemy_count = 0;
         stage_time = 0;
         
         enemyX_Inc.clear();
         enemyY_Inc.clear();
         
         for(int i = 0; i < 3; i++) {
            enemylazer[i] = true;
         }
         
         for(int i=0; i<EnemyList.size();i++) {
            enemyX_Inc.add(0.0);
            enemyY_Inc.add(0.0);
         }

         EnemyList.get(0).setVisible(true);
      }
	   
	private void setStage5() {
	      EnemyList.clear();
	      EnemyList_Xspeed.clear();
	      EnemyList_Yspeed.clear();
	      EnemyList_Xspeed_real.clear();
	      EnemyList_Yspeed_real.clear();
	      
	      // enemy1
	      EnemyList.add(enemy51);
	      EnemyList_Xspeed.add(0.035);
	      EnemyList_Yspeed.add(0.035);
	      EnemyList_Xspeed_real.add(0.0);
	      EnemyList_Yspeed_real.add(0.0);
	      
	      // enemy2
	      EnemyList.add(enemy52);
	      EnemyList_Xspeed.add(0.1);
	      EnemyList_Yspeed.add(0.1);
	      EnemyList_Xspeed_real.add(0.0);
	      EnemyList_Yspeed_real.add(0.0);
	      
	      // enemy3
	      EnemyList.add(enemy53);
	      EnemyList_Xspeed.add(0.001);
	      EnemyList_Yspeed.add(0.001);
	      EnemyList_Xspeed_real.add(0.0);
	      EnemyList_Yspeed_real.add(0.0);
	      
	      // enemy4
	      EnemyList.add(enemy54);
	      EnemyList_Xspeed.add(0.025);
	      EnemyList_Yspeed.add(0.025);
	      EnemyList_Xspeed_real.add(0.0);
	      EnemyList_Yspeed_real.add(0.0);
	      
	      enemyX_Inc.clear();
	      enemyY_Inc.clear();
	      
	      enemyXspeed = 0.03;
	      enemyYspeed = 0.03;
	      enemy_count = 0; //enemy ����
	      stage_time = 0; //���� �ð�
	      loopcount = 0;//
	      enemyRotate = 0;//
	      
	   }
	  
	private void stage3() {
	      double x, y;
	      Enemy_Attack3.setVisible(true);
	      if(Enemy_Attack3.isVisible()) {
	         if(enemy_count == 0) {
	            int y_;
	            
	            int x_ = (int)(Math.random() * 1000) % 471 + 250;
	            if(x_ < 300 || x_ > 670)
	               y_ = (int)(Math.random() * 1000) % 231 + 520;
	            else
	               y_ = 470;
	            
	            EnemyList.get(enemy_count).setLayoutX(x_);
	            EnemyList.get(enemy_count).setLayoutY(y_);
	            
	            x = player.getLayoutX() + player.getX() - EnemyList.get(enemy_count).getLayoutX();
	            y = player.getLayoutY() + player.getY() - EnemyList.get(enemy_count).getLayoutY();
	            
	            enemyX_Inc.set(enemy_count, Math.sin(Math.atan2(x, y)));
	            enemyY_Inc.set(enemy_count, Math.cos(Math.atan2(x, y)));
	            enemy_count++;
	            EnemyList.get(enemy_count).setVisible(true);
	         }
	         
	         else if(loopcount == 50 && enemy_count < EnemyList.size()) {
	            int y_;
	            
	            int x_ = (int)(Math.random() * 1000) % 471 + 250;
	            if(x_ < 300 || x_ > 670)
	               y_ = (int)(Math.random() * 1000) % 231 + 520;
	            else
	               y_ = 470;

	            EnemyList.get(enemy_count).setLayoutX(x_);
	            EnemyList.get(enemy_count).setLayoutY(y_);
	            
	            x = player.getLayoutX() + player.getX() - EnemyList.get(enemy_count).getLayoutX();
	            y = player.getLayoutY() + player.getY() - EnemyList.get(enemy_count).getLayoutY();
	            
	            enemyX_Inc.set(enemy_count, Math.sin(Math.atan2(x, y)));
	            enemyY_Inc.set(enemy_count, Math.cos(Math.atan2(x, y)));
	            EnemyList.get(enemy_count).setVisible(true);
	            enemy_count++;
	            loopcount = 0;
	         }
	         
	         stage_time = stage_time + timeLine.getCurrentTime().toSeconds();

	         for(int i=0; i<EnemyList.size();i++) {
	            EnemyList.get(i).setX(EnemyList.get(i).getX()+ enemyX_Inc.get(i) * enemyXspeed);
	            EnemyList.get(i).setY(EnemyList.get(i).getY()+ enemyY_Inc.get(i) * enemyYspeed);
	      
	            if(i == EnemyList.size() -1)
	               loopcount++;
	            
	            if(stage_time >= 7) {      // -20�� �����ϸ� ������
	               EnemyList.get(i).setVisible(false);
	               EnemyList.get(i).setLayoutX(-10);
	               EnemyList.remove(i);
	            }
	         }
	        }
	      if(EnemyList.isEmpty()) {			// �� ����������
	    	  PlayController.GAME_LEVEL = 4;
				setStage4();
			}
	      }
		
	private void stage4() {
         Enemy_Attack4.setVisible(true);
         if(Enemy_Attack4.isVisible()) {
            //enemy1,2,3 �̵�
            
            EnemyRotateX(0,3, true, 0);
            if(enemyUp[0]) {
               EnemyList.get(0).setY(EnemyList.get(0).getY() - 1);
               if(EnemyList.get(0).getY() + EnemyList.get(0).getLayoutY() <= 520)
                  enemyUp[0] = false;
            }
            
            else if (!enemyUp[0]){
               EnemyList.get(0).setY(EnemyList.get(0).getY() + 1);
               if(EnemyList.get(0).getY() + EnemyList.get(0).getLayoutY() >= 700)
                  enemyUp[0] = true;
            }
            
            if(enemyFlag[0]) {
               EnemyRotateX(1,5, false, 1);
               if(enemyUp[1]) {
                  EnemyList.get(1).setY(EnemyList.get(1).getY() - 1.6);
                  if(EnemyList.get(1).getY() + EnemyList.get(1).getLayoutY() <= 520)
                     enemyUp[1] = false;
               }
               
               else if (!enemyUp[1]){
                  EnemyList.get(1).setY(EnemyList.get(1).getY() + 1.6);
                  if(EnemyList.get(1).getY() + EnemyList.get(1).getLayoutY() >= 700)
                     enemyUp[1] = true;
               }
            }
            
            if(enemyFlag[1]) {
               EnemyRotateY(2,7);
               if(enemyUp[2]) {
                  EnemyList.get(2).setX(EnemyList.get(2).getX() - 2.5);
                  if(EnemyList.get(2).getX() + EnemyList.get(2).getLayoutX() <= 300)
                     enemyUp[2] = false;
               }
               
               else if (!enemyUp[2]){
                  EnemyList.get(2).setX(EnemyList.get(2).getX() + 2.5);
                  if(EnemyList.get(2).getX() + EnemyList.get(2).getLayoutX() >= 670)
                     enemyUp[2] = true;
               }
            }

            if(EnemyList.get(3).isVisible())
               EnemyList.get(3).setX(EnemyList.get(3).getX() - enemyXspeed);
            
            if(EnemyList.get(4).isVisible())
               EnemyList.get(4).setX(EnemyList.get(4).getX() - enemyXspeed);

            if(EnemyList.get(5).isVisible())
               EnemyList.get(5).setX(EnemyList.get(5).getX() + enemyXspeed);

            if(EnemyList.get(6).isVisible())
               EnemyList.get(6).setX(EnemyList.get(6).getX() + enemyXspeed);

            if(EnemyList.get(7).isVisible())
               EnemyList.get(7).setY(EnemyList.get(7).getY() + enemyYspeed);
            
            if(EnemyList.get(8).isVisible())
               EnemyList.get(8).setY(EnemyList.get(8).getY() + enemyYspeed);
            
            if(EnemyList.get(3).getX() <= -720) {
               EnemyList.get(3).setVisible(false);
               EnemyList.get(3).setX(0);
            }
            
            if(EnemyList.get(4).getX() <= -720) {
               EnemyList.get(4).setVisible(false);
               EnemyList.get(4).setX(0);
            }
            
            if(EnemyList.get(5).getX() >= 720) {
               EnemyList.get(5).setVisible(false);
               EnemyList.get(5).setX(0);
            }
            
            if(EnemyList.get(6).getX() >= 720) {
               EnemyList.get(6).setVisible(false);
               EnemyList.get(6).setX(0);
            }
            
            if(EnemyList.get(7).getY() >= 250) {
               EnemyList.get(7).setVisible(false);
               EnemyList.get(7).setY(0);
            }
            
            if(EnemyList.get(8).getY() >= 250) {
               EnemyList.get(8).setVisible(false);
               EnemyList.get(8).setY(0);
            }

            loopcount++;
            
            if(loopcount == 40) {
               EnemyList.get(1).setVisible(true);
               enemyFlag[0] = true;
            }
            else if(loopcount == 120) {
               EnemyList.get(2).setVisible(true);
               enemyFlag[1] = true;
            }
            if(loopcount > 1000) {
               for(int i=EnemyList.size()-1; i>=0; i--) {
                  EnemyList.get(i).setVisible(false);
                  EnemyList.get(i).setLayoutX(-180);
                  EnemyList.remove(i);
                  if(i==0) {
                     Enemy_Attack4.setVisible(false);
                  }
               }
            }
         }
         if(EnemyList.isEmpty()) {         // �� ����������
            PlayController.GAME_LEVEL=5;
            setStage5();
         }
      }
	
	private void stage5() {
	      Enemy_Attack5.setVisible(true);
	      Enemy_Attack5_time = Enemy_Attack5_time + timeLine.getCurrentTime().toSeconds();
	      if(Enemy_Attack5.isVisible()) {
	    	  for(int i=0; i < EnemyList.size();i++) {
	    		 double enemyMinXpos = EnemyList.get(i).getBoundsInParent().getMinX();
	 	         double enemyMaxXpos = EnemyList.get(i).getBoundsInParent().getMaxX();
	 	         double enemyMinYpos = EnemyList.get(i).getBoundsInParent().getMinY();
	 	         double enemyMaxYpos = EnemyList.get(i).getBoundsInParent().getMaxY();
	 	         
	 	         double playerMinXpos = player.getBoundsInParent().getMinX();
	 	         double playerMaxXpos = player.getBoundsInParent().getMaxX();
	 	         double playerMinYpos = player.getBoundsInParent().getMinY();
	 	         double playerMaxYpos = player.getBoundsInParent().getMaxY();
	 	         
	 	        if(enemyMaxXpos > playerMinXpos) {
			       	if(EnemyList_Xspeed.get(i) > 0)  EnemyList_Xspeed.set(i, -EnemyList_Xspeed.get(i));
			    }
			    else if(enemyMinXpos < playerMaxXpos) {
			       	 if(EnemyList_Xspeed.get(i) < 0) EnemyList_Xspeed.set(i, -EnemyList_Xspeed.get(i)); 
			    }
			         
			    if(enemyMaxYpos > playerMinYpos) {
			        if(EnemyList_Yspeed.get(i) > 0) EnemyList_Yspeed.set(i, -EnemyList_Yspeed.get(i));	 
			    }
			    else if(enemyMinYpos < playerMaxYpos) {
			        if(EnemyList_Yspeed.get(i) < 0) EnemyList_Yspeed.set(i, -EnemyList_Yspeed.get(i));
			        	 
			    }
		         
		         EnemyList_Xspeed_real.set(i,EnemyList_Xspeed_real.get(i) + EnemyList_Xspeed.get(i));
		         EnemyList_Yspeed_real.set(i,EnemyList_Yspeed_real.get(i) + EnemyList_Yspeed.get(i));
		         
		         EnemyList.get(i).setX(EnemyList.get(i).getX() + EnemyList_Xspeed_real.get(i));
	        	 EnemyList.get(i).setY(EnemyList.get(i).getY() + EnemyList_Yspeed_real.get(i));
	        	 
	        	 
	    	  }
	      }
	      if(Enemy_Attack5_time > 10) {
	        	for(int i=0; i< EnemyList.size(); i++) {
	        		EnemyList.get(i).setVisible(false);
	        		EnemyList.get(i).setLayoutX(-10);
	        		EnemyList.remove(i);
	        	}
	        }
	        if(EnemyList.isEmpty()) {         // �� ����������
	            PlayController.GAME_LEVEL=6;
	        }
	   }
	
	private void gotoGameWin() throws IOException{
		Parent forth = FXMLLoader.load(getClass().getResource("GameOver.fxml"));
        Scene scene = new Scene(forth);
        Stage stage =(Stage)gameover1.getScene().getWindow();
    	sound.BGMstop("game2");
        stage.setScene(scene);
        stage.setTitle("Victoriy..");
	}

	private void gotoGameOver() throws IOException{
		PlayController.PlayerScore ="F";
		Parent third = FXMLLoader.load(getClass().getResource("GameOver.fxml"));
        Scene scene = new Scene(third);
        Stage stage =(Stage)gameover1.getScene().getWindow();
        sound.BGMstop("game2");
        stage.setScene(scene);
        stage.setTitle("GameOver..");
	}
	
	private boolean crash() {
		for(int i=0; i<EnemyList.size();i++) {
			if(EnemyList.get(i).getBoundsInParent().getMinX() < player.getBoundsInParent().getMaxX() &&
				EnemyList.get(i).getBoundsInParent().getMinY() < player.getBoundsInParent().getMaxY() &&
				EnemyList.get(i).getBoundsInParent().getMaxX() > player.getBoundsInParent().getMinX() &&
				EnemyList.get(i).getBoundsInParent().getMaxY() > player.getBoundsInParent().getMinY()) {
				return true;
			}
		}
		return false;
	}
	
	private void handlePlayer_1(KeyEvent event) throws IOException {
		KeyCode keyCode = event.getCode();
		
		if (keyCode.equals(KeyCode.RIGHT)) {
			Key_right = true;
		}
		else if (keyCode.equals(KeyCode.LEFT)) {
            Key_left = true;
        }
		else if (keyCode.equals(KeyCode.UP)) {
            Key_up = true;
        }
		else if (keyCode.equals(KeyCode.DOWN)) {
            Key_down = true;
        }
	}
	
	private void handlePlayer_2(KeyEvent event) throws IOException {
		KeyCode keyCode = event.getCode();
		if (keyCode.equals(KeyCode.RIGHT)) {
			Key_right = false;
		}
		else if (keyCode.equals(KeyCode.LEFT)) {
            Key_left = false;
        }
		else if (keyCode.equals(KeyCode.UP)) {
            Key_up = false;
        }
		else if (keyCode.equals(KeyCode.DOWN)) {
            Key_down = false;
        }
	}

	private void move_player() {
		if(Key_up && Key_right) {					// ������ ��
			player.setX(player.getX() + player_speed);			// ������ �ѹ�
			player.setY(player.getY() - player_speed);			// ���� �ѹ�
			 
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		else if(Key_right && Key_up) {					// �� ������
			player.setX(player.getX() + player_speed);			// ������ �ѹ�
			player.setY(player.getY() - player_speed);			// ���� �ѹ�
			 
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		else if(Key_up && Key_left) {					// ���� ��
			player.setX(player.getX() - player_speed);				// �������� �� ĭ 
			player.setY(player.getY() - player_speed);				// ���� �� ĭ
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		
		else if(Key_left && Key_up) {					// ���� ��
			player.setX(player.getX() - player_speed);				// �������� �� ĭ 
			player.setY(player.getY() - player_speed);				// ���� �� ĭ
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		
		else if(Key_down && Key_right) {				// ������ �Ʒ�
			player.setX(player.getX() + player_speed);
			player.setY(player.getY() + player_speed);
			
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		else if(Key_right && Key_down) {				// ������ �Ʒ�
			player.setX(player.getX() + player_speed);
			player.setY(player.getY() + player_speed);
			
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_down && Key_left) {					// ���� �Ʒ�
			player.setX(player.getX() - player_speed);
			player.setY(player.getY() + player_speed);
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_left && Key_down) {					// ���� �Ʒ�
			player.setX(player.getX() - player_speed);
			player.setY(player.getY() + player_speed);
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_up) {
			player.setY(player.getY() - player_speed);
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		
		else if(Key_down) {
			player.setY(player.getY() + player_speed);
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_left) {
			player.setX(player.getX() - player_speed);	
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
		}
		else if(Key_right) {
			player.setX(player.getX() + player_speed);
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
		}
	}

	private void game_end_set() {
		timeLine.stop();
		for(int i=0; i<StageList.size(); i++) {
			StageList.get(i).setVisible(false);
		}
	}
		   
	private void EnemyRotateX(int n, int m, boolean right, int k) {
      int temp = m;
      int i = -1;
      
      if(!enemylazer[k]) {
         temp += 1;
      }
      
       if(right)
          i = 1;
         
       if(EnemyList.get(n).getRotate() < 270) {
          EnemyList.get(n).setVisible(true);
          EnemyList.get(n).setRotate(EnemyList.get(n).getRotate() + enemyRotate);
       }
       else {
          EnemyList.get(temp).setLayoutX(EnemyList.get(n).getLayoutX() - 40  * i);
          EnemyList.get(temp).setLayoutY(EnemyList.get(n).getLayoutY() + EnemyList.get(n).getY() + 25);
          EnemyList.get(temp).setVisible(true);
          EnemyList.get(n).setRotate(0);
          if(enemylazer[k])
             enemylazer[k] = false;
          else
             enemylazer[k] = true;
         }
      }
      
    private void EnemyRotateY(int n, int m) {
      int temp = m;
   
      if(!enemylazer[2]) {
         temp += 1;
      }
      
      if(EnemyList.get(n).getRotate() < 270) {
         EnemyList.get(n).setVisible(true);
         EnemyList.get(n).setRotate(EnemyList.get(n).getRotate() + enemyRotate);
      }
      else {
         EnemyList.get(temp).setLayoutX(EnemyList.get(n).getLayoutX() + EnemyList.get(n).getX() + 25);
         EnemyList.get(temp).setLayoutY(EnemyList.get(n).getLayoutY() + 40);
         EnemyList.get(temp).setVisible(true);
         EnemyList.get(n).setRotate(0);
         if(enemylazer[2])
            enemylazer[2] = false;
         else
            enemylazer[2] = true;
         }
      }

}