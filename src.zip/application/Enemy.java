package application;

public class Enemy {
	
	int x, y, speed;
	
	
	public Enemy(int x, int y, int speed) {
		this.x = x;
		this.y = y;
		this.speed = speed;
	}
	
	public void stage_1_move() {			// �������� 1 ����
		x = x + speed;
	}
	
}
