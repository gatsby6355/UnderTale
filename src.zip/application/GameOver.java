package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GameOver implements Initializable{
	@FXML
	Text Exit;
	@FXML
	Pane Background_1, Go_main, hand;
	@FXML
	ImageView check1, check2, check3, check4, check5, background1;
	@FXML
	ImageView board, hand1, hand2, hand3, hand4;
	
	ArrayList <ImageView> handlist = new ArrayList<ImageView>();
	Timeline timeLine;
	double run_time=0, run_time_bg=0, upOpacity = 0.01;
	int background1_time = 0, bg_op =0;
	boolean hand_flag1 = false;
	boolean check_score = false;
	boolean GoMain = false;
	
	
	private FXSound sound = new FXSound();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//set a BGM
		if(PlayController.PlayerScore.equals("F")) {
			sound.BGMPlay("gameover");
		}
		else {
			sound.BGMPlay("victory");
		}
		background1.setVisible(true);
		board.setVisible(false);
		handlist.add(hand1);
		handlist.add(hand2);
		handlist.add(hand3);
		handlist.add(hand4);
		
		Exit.setOnMouseClicked(event->{
            try {
                handleBtnGo(event);
            } catch (IOException e) {
                e.printStackTrace();
            }});
		
		timeLine  = new Timeline(new KeyFrame(Duration.millis(10), e-> run()));
	    timeLine.setCycleCount(Timeline.INDEFINITE);
	    timeLine.play();
	}
	
    private void run() {
    	if(background1_time < 10){
    		run_time_bg = run_time_bg + timeLine.getCurrentTime().toSeconds();
    		if(run_time_bg > 0.5) {
    			run_time_bg = 0;
    			if(bg_op == 0) bg_op = 1;
    			else if(bg_op == 1) bg_op = 0;
    			background1.setOpacity(bg_op);
    		}
    	}
		run_time = run_time + timeLine.getCurrentTime().toSeconds();
		if(!hand_flag1) {
			if(run_time > 1.5 && run_time < 3) {
				board.setVisible(true);
				board.setY(board.getY() + 0.9);
			}
			if(run_time > 4.5) {
				run_time = 0;
				hand_flag1 = true;
			}
		}
		else {
			if(!check_score) {
				check_score = true;
				if(PlayController.PlayerScore.charAt(0) == 'A') {
					check1.setVisible(true);
				}
				else if(PlayController.PlayerScore.charAt(0) == 'B') {
					check2.setVisible(true);
				}
				else if(PlayController.PlayerScore.charAt(0) == 'C') {
					check3.setVisible(true);
				}
				else if(PlayController.PlayerScore.charAt(0) == 'D') {
					check4.setVisible(true);
				}
				else {
					check5.setVisible(true);
				}
			}
			if(run_time < 3) {
				hand.setVisible(true);
				for(int i=0; i<handlist.size();i++) {
					handlist.get(i).setOpacity(handlist.get(i).getOpacity() + upOpacity);
				}
				
			}else if(run_time > 3) {
				timeLine.stop();
				if(!GoMain) {
					GoMain = true;
				}
			}
			Background_1.setOnMouseClicked(event -> open_pane());
		}
	}

	private void open_pane() {
		Go_main.setVisible(true);
	}

	/* ȭ���̵� �޼ҵ�*/
    public void handleBtnGo(MouseEvent event) throws IOException {
        Parent second = FXMLLoader.load(getClass().getResource("MainUI.fxml"));
        Scene scene = new Scene(second);
        Stage primaryStage =(Stage)Exit.getScene().getWindow();
    	sound.BGMstop("victory");
        primaryStage.setScene(scene);
        primaryStage.setTitle("����ȭ��");
    }
 
}
