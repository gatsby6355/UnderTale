package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GameOver implements Initializable{

	@FXML
	Text Retry;
	
	private FXSound sound = new FXSound();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// set a BGM
		sound.BGMPlay("gameover");
		
		Retry.setOnMouseClicked(event -> {
			try {
				PlayScene(event);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

	}

	private void PlayScene(MouseEvent event) throws IOException {
		Parent second = FXMLLoader.load(getClass().getResource("Play.fxml"));
        Scene scene = new Scene(second);
        Stage primaryStage =(Stage)Retry.getScene().getWindow();
    	sound.BGMstop("gameover");
        primaryStage.setScene(scene);
        primaryStage.setTitle("����ȭ��");
	}
		
}
