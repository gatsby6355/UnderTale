package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PlayController implements Initializable{
	
	@FXML
	private ImageView player, background_material_1, boss_face1, boss_face2;
	@FXML
	private ImageView enemy01A, enemy01B, enemy01C, enemy01D, enemy01E,
	enemy02A, enemy02B, enemy02C, enemy02D, enemy02E,
	enemy03A, enemy03B, enemy03C, enemy03D, enemy03E,
	enemy04A, enemy04B, enemy04C, enemy04D, enemy04E;		// Stage 0
	@FXML
	private ImageView enemy11, enemy12, enemy13, enemy14, enemy15, enemy16, enemy17, enemy18;		// Stage 1
	@FXML
	private ImageView enemy21, enemy22, enemy23, enemy24, enemy25, enemy26, enemy27, enemy28, enemy29;		// Stage 2
	@FXML
    private Rectangle play_area;
	@FXML
	private Pane bossA_tf, gameover_pane1, gameover_pane2;
	@FXML
	private Label playtime;
	@FXML
	private Pane Enemy_Attack0, Enemy_Attack1, Enemy_Attack2;
	@FXML
	private Button gameover1;
	@FXML
	private Text player_score, chat_hit, chat_usual1, chat_usual2, chat_usual3;
	
	private FXSound sound = new FXSound();
	
	public static ArrayList<ImageView> EnemyList = new ArrayList<ImageView>();		// ���� �����ϴ� �迭
	public static ArrayList<Pane> StageList = new ArrayList<Pane>();				// ������ �����ϴ� �迭
	
	public final static int width = 1024;
	public final static int height = 768;
	
	public static int GAME_LEVEL = -1;			// ���� ����
	static double delaytime = 2;				// �ǰ� ������ �ð�
	
	boolean Key_up = false;
	boolean Key_down = false;
	boolean Key_left = false;
	boolean Key_right = false;
	
	static boolean boss_chat = false;
	static double boss_chat_delay = 4;
	static double boss_chat_delaytime = 0;
	static int random_chat=0;
	ArrayList <Text> boss_chat_list = new ArrayList<Text>();
	
	static int PLAYER_HP = 3;
	static boolean player_state = false;
	static boolean player_state_delay = false;
	static double player_state_delaytime = 0;
	static double playerXpos = 0;
	static double playerYpos = 0;
	static int player_speed = 1;
	
	static int enemyXpos = 0;
	static int enemyYpos = 0;
	static double enemyXspeed = 0;
	static double enemyYspeed = 0;
	
	static int textview = 0;
	public Timeline timeLine;
	public static String PlayerScore ="A";
	
	boolean stage0_flag1= false;
	boolean stage0_flag2= false;
	boolean stage0_flag3= false;
	boolean stage0_flag4= false;
	boolean stage0_flag5= false;
	boolean stage0_flag6= false;
	double stage0_time = 0;
	
	boolean stage1_flag1= false;
	boolean stage1_flag2= false;
	boolean stage1_flag3= false;
	boolean stage1_flag4= false;
	double stage1_time = 0;
	

	@Override
	public void initialize(URL location, ResourceBundle resources){
		
		
		initial_game();
		Enemy_Attack1.setVisible(false);
		bossA_tf.setVisible(true);
		bossA_tf.setOnKeyReleased(event -> text_view(event));
		
		player.setOnKeyPressed(event -> {
			try {
				handlePlayer_1(event);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		
		player.setOnKeyReleased(event -> {
			try {
				handlePlayer_2(event);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		
		timeLine = new Timeline(new KeyFrame(Duration.millis(10), e-> run(e)));
		timeLine.setCycleCount(Timeline.INDEFINITE);
		timeLine.play();
	}

	private void initial_game() {
		//bgm play
		sound.BGMPlay("game");
		background_material_1.setVisible(false);
		
		//player
		PLAYER_HP = 3;
		player_state = false;
		player_state_delaytime = 0;
		player_score.setText("A");
		
		// set game level
		stage0_time = 0;
		stage1_time = 0;
		setStage0();
		GAME_LEVEL = -1;
		player_state = false;
		
		//boss chat
		bossA_tf.setVisible(false);
		boss_chat = false;
		chat_hit.setVisible(false);
		chat_usual1.setVisible(false);
		chat_usual2.setVisible(false);
		chat_usual3.setVisible(false);
		boss_chat_list.add(chat_usual1);
		boss_chat_list.add(chat_usual2);
		boss_chat_list.add(chat_usual3);
		
		// set Key
		Key_up = false;
		Key_down = false;
		Key_left = false;
		Key_right = false;
		
		// add the stage pane
		Enemy_Attack0.setVisible(false);
		Enemy_Attack1.setVisible(false);
		Enemy_Attack2.setVisible(false);
		
		StageList.clear();
		StageList.add(Enemy_Attack0);
		StageList.add(Enemy_Attack1);
		StageList.add(Enemy_Attack2);
	}

	private void run(ActionEvent e){
		
		// set Xpos, Ypos
		playerXpos = player.getX();
		playerYpos = player.getY();
		player_state = crash();
		
		move_player();
		if(textview == 2) {
			boss_chat_usual();
		}
		
		// �ǰ� �� �����̰� �����ϸ�,
		if(player_state_delay) {		// ������ player_state�� true ����
			player_state_delaytime = player_state_delaytime + timeLine.getCurrentTime().toSeconds();
			if(player_state) {
				player_state = false;
			}
			if(delaytime < player_state_delaytime) {
				player_state_delay = false;
				player_state_delaytime = 0;
			}
		}
		else {
			if(player_state) {			// �ǰݽ�
				PLAYER_HP--;
				player_state_delay = true;
				boss_chat_hit();
			}
		}

		// **GAME_LEVEL
		if(GAME_LEVEL == 0) {
			stage0();
		}
		else if(GAME_LEVEL == 1) {
			stage1();
		}
		else if(GAME_LEVEL == 2) {
			stage2();
		}
		else if(GAME_LEVEL == 3) {			// �¸��� ���
			gameover_pane2.setVisible(true);
			game_end_set();
			player.setFocusTraversable(false);
			gameover_pane2.setFocusTraversable(true);
			gameover_pane2.setOnKeyPressed(event -> {
				try {
					gotoNextStage(event);
				} catch (IOException e1) {
						e1.printStackTrace();
				}
			});
		}
		
		// ** PLAYER_SCORE
		if(PLAYER_HP == 3) {
			player_score.setText("A");
		}
		else if(PLAYER_HP == 2) {
			player_score.setText("B");
		}
		else if(PLAYER_HP == 1) {
			player_score.setText("C");
		}
		else if(PLAYER_HP == 0) {					// ���� ���
			gameover_pane1.setVisible(true);
			game_end_set();
			gameover1.setOnAction(event->{
				try {
					gotoGameOver();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			});
		}
	}
	
	private void boss_chat_hit() {
		boss_hit_motion1();
		if(boss_chat) {			// boss_chat�� �����ִ°�� 
			boss_chat=false;
		}
		boss_face1.setVisible(false);
		boss_face2.setVisible(true);
		sound.EffectPlay("pitan");
		boss_chat_delaytime = -2;
		chat_hit.setVisible(true);
		boss_chat_list.get(random_chat).setVisible(false);
	}
	
	private void boss_chat_usual() {
		boss_chat_delaytime =  boss_chat_delaytime + timeLine.getCurrentTime().toSeconds();
		
		if(boss_chat_delaytime > 0) {
			chat_hit.setVisible(false);
			boss_hit_motion2();
			boss_face2.setVisible(false);
			boss_face1.setVisible(true);
		}
		
		if(!boss_chat) {
			if(boss_chat_delaytime > boss_chat_delay) {	// 4�� ���� ��ȭ�� �ٲ�
			random_chat = (int)(Math.random()*boss_chat_list.size());
			boss_chat_list.get(random_chat).setVisible(true);
			boss_chat = true;
			}
		}
		else {
			if(boss_chat_delaytime > 5.5) {
				boss_chat_list.get(random_chat).setVisible(false);		// ���� �� false
				boss_chat_delaytime=0;
				boss_chat=false;
			}
		}
		
	}
	
	private void boss_hit_motion1() {
		background_material_1.setVisible(true);
		double i=0.3;
		while(i > 0.5){
			background_material_1.setOpacity(i);
			i = i + 0.1;
		}
	}
	
	private void boss_hit_motion2() {
		double i=0.5;
		while(i < 0.3){
			background_material_1.setOpacity(i);
			i = i - 0.1;
		}
		background_material_1.setVisible(false);
	}

	private void setStage0() {
		EnemyList.clear();
		EnemyList.add(enemy01A);
		EnemyList.add(enemy01B);
		EnemyList.add(enemy01C);
		EnemyList.add(enemy01D);
		EnemyList.add(enemy01E);
		
		EnemyList.add(enemy02A);
		EnemyList.add(enemy02B);
		EnemyList.add(enemy02C);
		EnemyList.add(enemy02D);
		EnemyList.add(enemy02E);
		
		EnemyList.add(enemy03A);
		EnemyList.add(enemy03B);
		EnemyList.add(enemy03C);
		EnemyList.add(enemy03D);
		EnemyList.add(enemy03E);
		
		EnemyList.add(enemy04A);
		EnemyList.add(enemy04B);
		EnemyList.add(enemy04C);
		EnemyList.add(enemy04D);
		EnemyList.add(enemy04E);
		
		enemyXspeed = 1;
		enemyYspeed = 1;
	}
	
	private void setStage1() {
		EnemyList.clear();
		EnemyList.add(enemy11);
		EnemyList.add(enemy12);
		EnemyList.add(enemy13);
		EnemyList.add(enemy14);
		EnemyList.add(enemy15);
		EnemyList.add(enemy16);
		EnemyList.add(enemy17);
		EnemyList.add(enemy18);
		enemyXspeed = 1;
		enemyYspeed = 0;
	}

	private void setStage2() {
		EnemyList.clear();
		EnemyList.add(enemy21);
		EnemyList.add(enemy22);
		EnemyList.add(enemy23);
		EnemyList.add(enemy24);
		EnemyList.add(enemy25);
		EnemyList.add(enemy26);
		EnemyList.add(enemy27);
		EnemyList.add(enemy28);
		EnemyList.add(enemy29);
		enemyXspeed = 1;
		enemyYspeed = 0;
	}
	
    private void stage0() {
		Enemy_Attack0.setVisible(true);
		if(Enemy_Attack0.isVisible() && !stage0_flag1) {
			for(int i=0; i<EnemyList.size();i++) {
				EnemyList.get(i).setX(EnemyList.get(i).getX()+enemyXspeed);
				EnemyList.get(i).setY(EnemyList.get(i).getY()+enemyYspeed);
				
				if(EnemyList.get(19).getBoundsInParent().getMinX() > 677 && 
						EnemyList.get(19).getBoundsInParent().getMinY() >588) {
					stage0_flag1 = true;
					stage0_flag2 = true;
					EnemyList.remove(15);
					EnemyList.remove(10);
					EnemyList.remove(5);
					EnemyList.remove(0);
					enemyXspeed = -2;
					enemyYspeed = 2;
				}
			}
		}
		if(stage0_flag1) {
			stage0_time = stage0_time + timeLine.getCurrentTime().toSeconds();
			for(int i=0; i<EnemyList.size();i++) {
				EnemyList.get(i).setX(EnemyList.get(i).getX()+enemyXspeed);
				EnemyList.get(i).setY(EnemyList.get(i).getY()+enemyYspeed);
				
				if(stage0_time > 0.2 && stage0_flag2) {
					if(i == 0){
						EnemyList.get(i).setVisible(true);
					}
					else if(i == 4) {
						EnemyList.get(i).setVisible(true);
					}
					else if(i == 8) {
						EnemyList.get(i).setVisible(true);
					}
					else if(i == 12) {
						EnemyList.get(i).setVisible(true);
						EnemyList.remove(12);
						EnemyList.remove(8);
						EnemyList.remove(4);
						EnemyList.remove(0);
						stage0_flag2 = false;
						stage0_flag3 = true;
						stage0_time = 0;
					}
				}
				
				if(stage0_time > 0.2 && stage0_flag3) {
					if(i == 0)		EnemyList.get(i).setVisible(true);
					else if(i == 3)	EnemyList.get(i).setVisible(true);
					else if(i == 6)	EnemyList.get(i).setVisible(true);
					else if(i == 9) {
						EnemyList.get(i).setVisible(true);
						EnemyList.remove(9);
						EnemyList.remove(6);
						EnemyList.remove(3);
						EnemyList.remove(0);
						stage0_flag3 = false;
						stage0_flag4 = true;
						stage0_time = 0;
					}
				}
				
				if(stage0_time > 0.2 && stage0_flag4) {
					if(i == 0)		EnemyList.get(i).setVisible(true);
					else if(i == 2)	EnemyList.get(i).setVisible(true);
					else if(i == 4)	EnemyList.get(i).setVisible(true);
					else if(i == 6) {
						EnemyList.get(i).setVisible(true);
						EnemyList.remove(6);
						EnemyList.remove(4);
						EnemyList.remove(2);
						EnemyList.remove(0);
						stage0_flag4 = false;
						stage0_flag5 = true;
						stage0_time = 0;
					}
				}
				
				if(stage0_time > 0.2 && stage0_flag5) {
					EnemyList.get(i).setVisible(true);
					EnemyList.remove(i);
					if(i==EnemyList.size()) {
						stage0_flag5 = false;
						stage0_time = 0;
						setStage0();
					}
				}
				
				if(!stage0_flag2 && !stage0_flag3 && !stage0_flag4 && !stage0_flag5) {
					EnemyList.get(i).setVisible(false);
					EnemyList.get(i).setLayoutX(-10);
					EnemyList.remove(i);
				}
			}
		}

		if(EnemyList.isEmpty()) {			// �� ����������
			GAME_LEVEL = 1;
			setStage1();
		}
	}
	
	private void stage1() {
		Enemy_Attack1.setVisible(true);
		if(Enemy_Attack1.isVisible() && stage1_flag1 == false) {
			for(int i=0; i<EnemyList.size();i++) {
				EnemyList.get(i).setX(EnemyList.get(i).getX()+enemyXspeed);
				EnemyList.get(i).setY(EnemyList.get(i).getY()+enemyYspeed);
				
				if(EnemyList.get(i).getBoundsInParent().getMaxX() > 285) {
					EnemyList.get(i).setVisible(true);
				}
				if(EnemyList.get(0).getBoundsInParent().getMaxX() > 578) {
					stage1_flag1 = true;
				}
			}
		}
		if(stage1_flag1) {
			for(int i=0;i<EnemyList.size();i++) {
				if(!stage1_flag2) {
					if(0 < i && i< 6) {
						EnemyList.get(i).setFitWidth(EnemyList.get(i).getFitWidth() + 1);
						if(EnemyList.get(5).getFitWidth() > 136) stage1_flag2 = true;
					}
				}
				if(!stage1_flag3) {
					if(i == 6 || i == 7) {
					EnemyList.get(i).setFitHeight(EnemyList.get(i).getFitHeight() + 2);
					if(EnemyList.get(7).getFitHeight() > 105) stage1_flag3 = true;
					}
				}
				if(stage1_flag2 && stage1_flag3) {
					stage1_time = stage1_time + timeLine.getCurrentTime().toSeconds();	
				}
				if(stage1_time > 1) stage1_flag4 = true;
			}
		}
		
		if(stage1_flag4) {
			for(int i=0;i<EnemyList.size();i++) {
				EnemyList.get(i).setVisible(false);
				EnemyList.get(i).setLayoutX(-10);
				EnemyList.remove(i);
			}
		}
		
		if(EnemyList.isEmpty()) {			// �� ����������
			GAME_LEVEL=2;
			setStage2();
		}
	}

	private void stage2() {
		Enemy_Attack2.setVisible(true);
		if(Enemy_Attack2.isVisible()) {
			for(int i=0; i<EnemyList.size();i++) {
				EnemyList.get(i).setX(EnemyList.get(i).getX()+enemyXspeed);
				EnemyList.get(i).setY(EnemyList.get(i).getY()+enemyYspeed);
				
				if(EnemyList.get(i).getBoundsInParent().getMaxX() > 285) {
					EnemyList.get(i).setVisible(true);;
				}
				
				if(EnemyList.get(i).getBoundsInParent().getMinX() > 750) {
					EnemyList.get(i).setVisible(false);
					EnemyList.remove(i);
				}
				
			}
		}
		if(EnemyList.isEmpty()) {			// �� ����������
			GAME_LEVEL = 3;
		}
	}

	private void gotoNextStage(KeyEvent event) throws IOException{
		KeyCode keyCode = event.getCode();
		if(keyCode.equals(KeyCode.X)) {
			gameover_pane2.setVisible(false);
			Parent forth = FXMLLoader.load(getClass().getResource("Play2.fxml"));
			Scene scene = new Scene(forth);
	    	sound.BGMstop("game");
	        Main.stage.setScene(scene);
	        Main.stage.setTitle("Playing..");
		}
	}

	private void gotoGameOver() throws IOException{
		Parent third = FXMLLoader.load(getClass().getResource("GameOver.fxml"));
        Scene scene = new Scene(third);
        //Stage stage =(Stage)gameover1.getScene().getWindow();
        sound.BGMstop("game");
        Main.stage.setScene(scene);
        Main.stage.setTitle("GameOver..");
	}
	
	private boolean crash() {
		for(int i=0; i<EnemyList.size();i++) {
			if(EnemyList.get(i).getBoundsInParent().getMinX() < player.getBoundsInParent().getMaxX() &&
				EnemyList.get(i).getBoundsInParent().getMinY() < player.getBoundsInParent().getMaxY() &&
				EnemyList.get(i).getBoundsInParent().getMaxX() > player.getBoundsInParent().getMinX() &&
				EnemyList.get(i).getBoundsInParent().getMaxY() > player.getBoundsInParent().getMinY()) {
				return true;
			}
		}
		return false;
	}
	
	private void text_view(KeyEvent event) {
		KeyCode keyCode = event.getCode();
		if(keyCode.equals(KeyCode.X)) {
			bossA_tf.setVisible(false);
			player.setFocusTraversable(true);
			GAME_LEVEL=0;
			textview = 2;
		}
	}

	private void handlePlayer_1(KeyEvent event) throws IOException {
		KeyCode keyCode = event.getCode();
		
		if (keyCode.equals(KeyCode.RIGHT)) {
			Key_right = true;
		}
		else if (keyCode.equals(KeyCode.LEFT)) {
            Key_left = true;
        }
		else if (keyCode.equals(KeyCode.UP)) {
            Key_up = true;
        }
		else if (keyCode.equals(KeyCode.DOWN)) {
            Key_down = true;
        }
	}
	
	private void handlePlayer_2(KeyEvent event) throws IOException {
		KeyCode keyCode = event.getCode();
		if (keyCode.equals(KeyCode.RIGHT)) {
			Key_right = false;
		}
		else if (keyCode.equals(KeyCode.LEFT)) {
            Key_left = false;
        }
		else if (keyCode.equals(KeyCode.UP)) {
            Key_up = false;
        }
		else if (keyCode.equals(KeyCode.DOWN)) {
            Key_down = false;
        }
	}

	private void move_player() {
		if(Key_up && Key_right) {					// ������ ��
			player.setX(player.getX() + player_speed);			// ������ �ѹ�
			player.setY(player.getY() - player_speed);			// ���� �ѹ�
			 
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		else if(Key_right && Key_up) {					// �� ������
			player.setX(player.getX() + player_speed);			// ������ �ѹ�
			player.setY(player.getY() - player_speed);			// ���� �ѹ�
			 
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		else if(Key_up && Key_left) {					// ���� ��
			player.setX(player.getX() - player_speed);				// �������� �� ĭ 
			player.setY(player.getY() - player_speed);				// ���� �� ĭ
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		
		else if(Key_left && Key_up) {					// ���� ��
			player.setX(player.getX() - player_speed);				// �������� �� ĭ 
			player.setY(player.getY() - player_speed);				// ���� �� ĭ
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		
		else if(Key_down && Key_right) {				// ������ �Ʒ�
			player.setX(player.getX() + player_speed);
			player.setY(player.getY() + player_speed);
			
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		else if(Key_right && Key_down) {				// ������ �Ʒ�
			player.setX(player.getX() + player_speed);
			player.setY(player.getY() + player_speed);
			
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_down && Key_left) {					// ���� �Ʒ�
			player.setX(player.getX() - player_speed);
			player.setY(player.getY() + player_speed);
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_left && Key_down) {					// ���� �Ʒ�
			player.setX(player.getX() - player_speed);
			player.setY(player.getY() + player_speed);
			
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_up) {
			player.setY(player.getY() - player_speed);
			if(-playerYpos> (play_area.getHeight()/2) - 10) {
				player.setY(player.getY() + player_speed);
			}
		}
		
		else if(Key_down) {
			player.setY(player.getY() + player_speed);
			if(playerYpos> (play_area.getHeight()/2) - 5) {
				player.setY(player.getY() - player_speed);
			}
		}
		
		else if(Key_left) {
			player.setX(player.getX() - player_speed);	
			if(-playerXpos > (play_area.getWidth()/2) - 10) {
            	player.setX(player.getX() + player_speed);
            }
		}
		else if(Key_right) {
			player.setX(player.getX() + player_speed);
			if(playerXpos> (play_area.getWidth()/2) - 5) {
				player.setX(player.getX() - player_speed);
			}
		}
	}

	private void game_end_set() {
		timeLine.stop();
		for(int i=0; i<StageList.size(); i++) {
			StageList.get(i).setVisible(false);
		}
	}
}