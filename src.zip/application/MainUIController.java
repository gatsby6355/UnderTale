package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainUIController implements Initializable {
  
	@FXML
	private ImageView background, GameStart, GameExit;
	
	private FXSound sound = new FXSound();
	
	double op = 0.32;
	double op_speed = 0.002;
	Timeline timeLine;
	
	@Override
    public void initialize(URL location, ResourceBundle resources) {
        /*ȭ�� �̵�*/
    	GameStart.setOnMouseClicked(event -> {
			try {
				handleNextGo();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
    	
    	GameExit.setOnMouseClicked(event -> System.exit(0));
    	
       sound.BGMPlay("main");
       
       timeLine  = new Timeline(new KeyFrame(Duration.millis(10), e-> run()));
       timeLine.setCycleCount(Timeline.INDEFINITE);
       timeLine.play();
    } // initialize()
    
    private void run() {
    	if(0.31 < op && op <0.83) {
    		op = op + op_speed;
    	}
    	else {
    		op_speed = -op_speed;
    		op = op + op_speed;
    	}
		background.setOpacity(op);
		
	}

	/* ȭ���̵� �޼ҵ�*/
   public void handleNextGo() throws IOException {
        Parent second = FXMLLoader.load(getClass().getResource("Play.fxml"));
        Scene scene = new Scene(second);
        Stage primaryStage =(Stage)GameStart.getScene().getWindow();
        primaryStage.setScene(scene);
        primaryStage.setTitle("����ȭ��");
        sound.BGMstop("main");
    }
 
 
}