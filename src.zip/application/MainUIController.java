package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
 
public class MainUIController implements Initializable {
  
	@FXML
	private Button GameStart, GameExit;
	
	private FXSound sound = new FXSound();
	
	@Override
    public void initialize(URL location, ResourceBundle resources) {
        /*ȭ�� �̵�*/
    	GameStart.setOnAction(event->{
            try {
                handleBtnGo(event);
            } catch (IOException e) {
                e.printStackTrace();
            }});
    	
        GameExit.setOnAction(event->{
        	System.exit(0);
        });
        
       sound.BGMPlay("main");
    } // initialize()
    
    /* ȭ���̵� �޼ҵ�*/
    public void handleBtnGo(ActionEvent event) throws IOException {
        Parent second = FXMLLoader.load(getClass().getResource("Play.fxml"));
        Scene scene = new Scene(second);
        Stage primaryStage =(Stage)GameStart.getScene().getWindow();
        primaryStage.setScene(scene);
        primaryStage.setTitle("����ȭ��");
        sound.BGMstop("main");
    }
 
 
}