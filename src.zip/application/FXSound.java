package application;

import java.util.HashMap;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class FXSound {
	private HashMap<String, AudioClip> effect_map = new HashMap<>();
	private HashMap<String, MediaPlayer> bgm_map = new HashMap<>();
	private Media main, game, game2, victory, gameover, bosschat;
	
	/* ù ������ ���� ���ҽ� �ε� */
	public FXSound() {
		System.out.println("[Init Game Resource]");
		try {
			System.out.print("Sound Loading.. ");
			main = new Media(Main.class.getResource("gamestart.mp3").toString());
			game = new Media(Main.class.getResource("mayo.mp3").toString());
			game2 = new Media(Main.class.getResource("game2.mp3").toString());
			victory = new Media(Main.class.getResource("playlist_1.mp3").toString());
			gameover = new Media(Main.class.getResource("gameover.mp3").toString());
			bosschat = new Media(Main.class.getResource("boss_chat_music.mp3").toString());

			// add bgm
			bgm_map.put("main", new MediaPlayer(main));
			bgm_map.put("game", new MediaPlayer(game));
			bgm_map.put("game2", new MediaPlayer(game2));
			bgm_map.put("victory", new MediaPlayer(victory));
			bgm_map.put("gameover", new MediaPlayer(gameover));
			bgm_map.put("bosschat", new MediaPlayer(bosschat));
			
			effect_map.put("pitan", new AudioClip(Main.class.getResource("pitan.mp3").toString()));
			
			System.out.println("Done!");
		} catch (Exception e) {
			System.out.println("Error!");
			e.printStackTrace();
		}
	}
	
	/* 1.25�� �ӵ��� ������� */
	public void BGMPlay(String key) {
		MediaPlayer temp = bgm_map.get(key);
		temp.setOnEndOfMedia(()->{ 
			temp.seek(Duration.ZERO); //���ѹݺ�
		});
		temp.setStartTime(Duration.seconds(65));
		temp.play();
		temp.setRate(1.25);
	}
	
	/* ���� ���� */
	public void BGMstop(String key) {
		try {
			MediaPlayer temp = bgm_map.get(key);
			temp.stop();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/* �ش��ϴ� Ű ���� ���带 ��� */
	public void EffectPlay(String key) {
		effect_map.get(key).play();
	}
}
