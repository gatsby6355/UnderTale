package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Victory implements Initializable{
	@FXML
	Label Score;
	@FXML
	Text Exit, VictoryText;
	@FXML
	Pane Background_1, Go_main;
	
	private FXSound sound = new FXSound();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		//set a BGM
		sound.BGMPlay("victory");
		
		//set a score
		Score.setText(PlayController.PlayerScore);
		VictoryText.setText("�����մϴ�. ����� "+PlayController.PlayerScore +"+������ ����߽��ϴ�.");
		
		Background_1.setOnMouseClicked(event -> open_pane());
		
		Exit.setOnMouseClicked(event->{
            try {
                handleBtnGo(event);
            } catch (IOException e) {
                e.printStackTrace();
            }});
	}
	
    private void open_pane() {
		Go_main.setVisible(true);
	}

	/* ȭ���̵� �޼ҵ�*/
    public void handleBtnGo(MouseEvent event) throws IOException {
        Parent second = FXMLLoader.load(getClass().getResource("MainUI.fxml"));
        Scene scene = new Scene(second);
        Stage primaryStage =(Stage)Exit.getScene().getWindow();
    	sound.BGMstop("victory");
        primaryStage.setScene(scene);
        primaryStage.setTitle("����ȭ��");
    }
 
}
